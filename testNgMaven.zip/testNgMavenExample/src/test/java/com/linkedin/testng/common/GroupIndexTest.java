package com.linkedin.testng.common;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.linkedin.testng.pageobjects.HomePageObjects;
import com.linkedin.testng.utils.TestUtils;

@Test(groups={"exclude"})
public class GroupIndexTest extends TestUtils{
	
	@Test (groups={"Regression"},priority=1)
	public static void getUrl1(){
		driver.navigate().to(baseUrl);
	}
	@Test (groups={"Regression"}, priority=2)
	public static void indexPage1(){
		Assert.assertEquals("LinkedIn: Log In or Sign Up", driver.getTitle());
	}
	@Test (groups={"Regression"}, priority=3)
	public static void visitForgotPasswordPage1() throws InterruptedException{
		HomePageObjects.forgotLink(driver).click();
		Thread.sleep(4000);
		Assert.assertEquals("Password Change | LinkedIn", driver.getTitle());
	}

	@Test (groups={"Regression"}, priority=4)
	public static void navigateIndexPage1() throws InterruptedException{
		HomePageObjects.signInLink(driver).click();
		Thread.sleep(4000);
		Assert.assertEquals("Sign In to LinkedIn", driver.getTitle());
	}


}
