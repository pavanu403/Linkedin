package com.linkedin.testng.utils;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

public class TestUtils {
	public static WebDriver driver;
	public static boolean isBrowserOpened = false;
	public static String baseUrl="https://www.linkedin.com/";
	@BeforeTest(groups={"Regression"})
	public void setup() throws Exception{
		if (!isBrowserOpened) {
			if(driver == null){
				driver = new FirefoxDriver();
				Thread.sleep(5000);
			}
			isBrowserOpened = true;
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}

	}

	@AfterTest(groups={"Regression"})
	public  void tearDown() throws Exception {
		driver.quit();
	}
}
