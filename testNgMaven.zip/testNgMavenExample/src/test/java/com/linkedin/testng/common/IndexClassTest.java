package com.linkedin.testng.common;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.linkedin.testng.pageobjects.HomePageObjects;
import com.linkedin.testng.utils.TestUtils;

@Test(groups={"include"})
public class IndexClassTest extends TestUtils{
	
	@Test (priority=1)
	public static void getUrl(){
		driver.get(baseUrl);
	}
	@Test (priority=2)
	public static void indexPage(){
		Assert.assertEquals("LinkedIn: Log In or Sign Up", driver.getTitle());
	}
	@Test (priority=3)
	public static void visitForgotPasswordPage() throws InterruptedException{
		HomePageObjects.forgotLink(driver).click();
		Thread.sleep(4000);
		Assert.assertEquals("Password Change | LinkedIn", driver.getTitle());
	}

	@Test (priority=4)
	public static void navigateIndexPage() throws InterruptedException{
		HomePageObjects.signInLink(driver).click();
		Thread.sleep(4000);
		Assert.assertEquals("Sign In to LinkedIn", driver.getTitle());
	}


}
