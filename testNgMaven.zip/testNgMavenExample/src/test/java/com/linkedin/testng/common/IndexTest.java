package com.linkedin.testng.common;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.linkedin.testng.pageobjects.HomePageObjects;
import com.linkedin.testng.utils.TestUtils;

@Test(groups={"exclude"})
public class IndexTest extends TestUtils{
	
	@Test (priority=1)
	public static void getUrl1(){
		driver.navigate().to(baseUrl);
	}
	@Test (priority=2)
	public static void indexPage1(){
		Assert.assertEquals("LinkedIn: Log In or Sign Up", driver.getTitle());
	}
	@Test (priority=3, enabled=false)
	public static void visitForgotPasswordPage1() throws InterruptedException{
		HomePageObjects.forgotLink(driver).click();
		Thread.sleep(4000);
		Assert.assertEquals("Password Change | LinkedIn", driver.getTitle());
	}

	@Test (priority=4, enabled=false)
	public static void navigateIndexPage1() throws InterruptedException{
		HomePageObjects.signInLink(driver).click();
		Thread.sleep(4000);
		Assert.assertEquals("Sign In to LinkedIn", driver.getTitle());
	}


}
