package com.linkedin.testng.pageobjects;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePageObjects {
	
private static WebElement element = null;
	
	public static WebElement forgotLink(WebDriver driver){
		element = driver.findElement(By.className("link-forgot-password"));
		return element;
	}
	
	public static WebElement signInLink(WebDriver driver){
		element = driver.findElement(By.xpath(".//*[@id='nav-primary-auth']/a/span"));
		return element;
	}

}
